http://www.posix.nl/linuxassembly/nasmdochtml/nasmdoca.html

TODOS:
- [x] Read contents of a file
- [ ] Read line by line
- [ ] Parse file contenets to see if a user is in the file
- [ ] Make a "user_in_file" subroutine
- [ ] Append to a file

qs:
- stderr, stdout for returns | only stdout
- what does he mean about /dev/null ? | not even anthony know
- should create user have _start? as well as the reste of the main files
- should the server program quit on user exists and should it print out the nok if run by the server?
